import User from '../model/User.js';
import Tool from '../model/Tool.js';
import Favorite from '../model/Favorite.js'; // if using favorites

export const getAdminStats = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalTools = await Tool.countDocuments();

    // Get most used category
    const categoryAgg = await Tool.aggregate([
      { $group: { _id: '$category', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 1 }
    ]);
    const mostUsedCategory = categoryAgg[0]?._id || 'N/A';

    // Get top favorited tool (if favorite collection exists)
    const favAgg = await Favorite.aggregate([
      { $group: { _id: '$tool', total: { $sum: 1 } } },
      { $sort: { total: -1 } },
      { $limit: 1 }
    ]);

    const topFavoritedTool = favAgg.length
      ? await Tool.findById(favAgg[0]._id).select('name logo')
      : null;

    res.json({
      totalUsers,
      totalTools,
      mostUsedCategory,
      topFavoritedTool
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
export const getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select('-password');
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
// PATCH /admin/users/:id/role
export const updateUserRole = async (req, res) => {
  try {
    const { role } = req.body; // 'user' or 'admin'

    if (!['user', 'admin'].includes(role)) {
      return res.status(400).json({ message: 'Invalid role' });
    }

    const user = await User.findByIdAndUpdate(req.params.id, { role }, { new: true }).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found' });

    res.json({ message: 'User role updated', user });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
// DELETE /admin/users/:id
export const deleteUser = async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

