import User from '../model/User.js';

export const toggleFavorite = async (req, res) => {
  try {
    const { toolId } = req.params;
    const user = await User.findById(req.user._id);

    const index = user.favorites.indexOf(toolId);

    if (index !== -1) {
      user.favorites.splice(index, 1); // remove
    } else {
      if (user.favorites.length >= 5) {
        return res.status(400).json({ message: 'Only 5 tools can be favorited' });
      }
      user.favorites.push(toolId); // add
    }

    await user.save();
    res.json({ message: 'Favorites updated', favorites: user.favorites });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getFavorites = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).populate('favorites');
    res.json(user.favorites);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
export const addFavorite = async (req, res) => {
  try {
    const user = req.user._id;
    const tool = req.params.toolId;

    const existingFavorites = await Favorite.find({ user });
    if (existingFavorites.length >= 5) {
      return res.status(400).json({ message: 'Max 5 favorites allowed' });
    }

    const exists = await Favorite.findOne({ user, tool });
    if (exists) {
      return res.status(400).json({ message: 'Tool already in favorites' });
    }

    const favorite = await Favorite.create({ user, tool });
    res.status(201).json({ message: 'Tool added to favorites', favorite });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get all favorites of a user
export const getUserFavorites = async (req, res) => {
  try {
    const favorites = await Favorite.find({ user: req.user._id }).populate('tool');
    res.json(favorites.map(fav => fav.tool));
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Remove a tool from favorites
export const removeFavorite = async (req, res) => {
  try {
    const { toolId } = req.params;
    await Favorite.findOneAndDelete({ user: req.user._id, tool: toolId });
    res.json({ message: 'Tool removed from favorites' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
