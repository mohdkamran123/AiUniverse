import jwt from 'jsonwebtoken';
import User from '../model/User.js';
import { sendOTPEmail } from '../utils/mailer.js';

// Generate JWT with role
const generateToken = (user) => {
  return jwt.sign(
    { id: user._id, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN }
  );
};

// ✅ Register Controller
export const registerUser = async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    const userExists = await User.findOne({ email });
    if (userExists) return res.status(400).json({ message: 'User already exists' });

    const user = await User.create({ name, email, password, role: role || 'user' });
    const token = generateToken(user);

    res.status(201).json({
      message: 'Registered successfully',
      token,
      userId: user._id,
      role: user.role
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ✅ Login (Send OTP)
export const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ message: 'Invalid credentials' });

    const isMatch = await user.comparePassword(password);
    if (!isMatch) return res.status(400).json({ message: 'Invalid credentials' });

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 min

    user.otp = { code: otp, expiresAt };
    await user.save();

    await sendOTPEmail(user.email, otp);

    res.status(200).json({ message: 'OTP sent to email', userId: user._id });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ✅ Verify OTP and issue JWT
// STEP 1: Send OTP during registration
export const sendRegisterOTP = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    const userExists = await User.findOne({ email });
    if (userExists) return res.status(400).json({ message: 'User already exists' });

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000);

    // Temporarily return OTP and full data (not safe in prod – use Redis or DB for temp storage)
    await sendOTPEmail(email, otp);

    res.status(200).json({
      message: 'OTP sent',
      tempData: { name, email, password, otp, expiresAt } // simulate temp user
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// STEP 2: Verify OTP and Create user
export const verifyRegisterOTP = async (req, res) => {
  try {
    const { name, email, password, otp, originalOtp, expiresAt } = req.body;

    if (!originalOtp || !otp) return res.status(400).json({ message: 'OTP missing' });

    if (otp !== originalOtp) return res.status(400).json({ message: 'Invalid OTP' });

    if (new Date() > new Date(expiresAt)) return res.status(400).json({ message: 'OTP expired' });

    const user = await User.create({ name, email, password });
    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN
    });

    res.status(201).json({ message: 'Registered successfully', token });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
