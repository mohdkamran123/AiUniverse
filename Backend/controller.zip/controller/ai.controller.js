// ✅ controller/ai.controller.js
import axios from 'axios';
import dotenv from 'dotenv';
import Tool from '../model/Tool.js';
dotenv.config();

export const generateAIResponse = async (req, res) => {
  const { toolId, prompt } = req.body;

  if (!prompt || !toolId) {
    return res.status(400).json({ success: false, message: 'Prompt and toolId are required' });
  }

  try {
    const tool = await Tool.findById(toolId);
    if (!tool) return res.status(404).json({ message: 'Tool not found' });

    const { integrationType, apiURL, apiKey, model } = tool;
    let aiResponse;

    if (integrationType === 'gemini') {
      const geminiPrompt = `You are an expert AI assistant. Respond to:\n"${prompt}"`;
      const response = await axios.post(
        `${apiURL}?key=${process.env[apiKey]}`,
        { contents: [{ parts: [{ text: geminiPrompt }] }] }
      );
      aiResponse = response.data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();

    } else if (["groq", "deepseek", "openrouter"].includes(integrationType)) {
      const response = await axios.post(
        apiURL,
        {
          model: model,
          messages: [{ role: 'user', content: prompt }]
        },
        {
          headers: {
            'Authorization': `Bearer ${process.env[apiKey]}`,
            'Content-Type': 'application/json'
          }
        }
      );
      aiResponse = response.data?.choices?.[0]?.message?.content?.trim();

    } else if (integrationType === 'deepai') {
      const response = await axios.post(
        apiURL,
        new URLSearchParams({ text: prompt }),
        {
          headers: {
            'api-key': process.env[apiKey],
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
      );
      aiResponse = response.data?.output?.trim();

    } else {
      return res.status(400).json({ message: 'Unsupported integration type' });
    }

    if (!aiResponse) {
      return res.status(500).json({ message: 'No response from AI' });
    }

    res.json({ success: true, answer: aiResponse });

  } catch (error) {
    console.error('AI Tool Error:', error.response?.data || error.message);
    res.status(500).json({ success: false, message: 'AI request failed' });
  }
};
